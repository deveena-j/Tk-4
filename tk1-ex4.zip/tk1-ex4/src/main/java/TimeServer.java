import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import static java.lang.Math.round;


public class TimeServer {
	private static int PORT = 27780;
	private ServerSocket serverSocket;
	NTPRequest mNtpRequest;
	private long serverOffset=1200;

	public TimeServer() {
		try {
			//waiting for connection
			serverSocket = new ServerSocket(PORT);
			System.out.println("Server started on port: " + PORT);


			while (true) {
				Socket incomingSocket = null;

				try {
					// socket object to receive incoming client requests
					incomingSocket = serverSocket.accept();

					// Handle the incoming NTP request on a new thread
					NTPRequestHandler ntpReqHandler = new NTPRequestHandler(incomingSocket);
					new Thread(ntpReqHandler).start();

					} catch (Exception e) {
					serverSocket.close();
					e.printStackTrace();
				}
			}
		}
		catch (IOException e) {
			e.printStackTrace();
			try {
				serverSocket.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

	}

	private void threadSleep(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new TimeServer();
	}

	private class NTPRequestHandler implements Runnable {
		private Socket clientSocket;

		public NTPRequestHandler(Socket client)
		{
			clientSocket = client;
		}

		@Override
		public void run() {
			InputStream is;
			try {
				is = clientSocket.getInputStream();
				ObjectInputStream oIs = new ObjectInputStream(is);
				mNtpRequest = (NTPRequest) oIs.readObject();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}

			// Emulate network delay - sleep before recording time stamps
			threadSleep(round(Math.random() * (100 - 10)) + 10);

			// set T2 value
			mNtpRequest.setT2(System.currentTimeMillis() + serverOffset);

			// add random delay between 10 to 100 ms - simulating processing delay (not required)
			threadSleep(round(Math.random() * (100 - 10)) + 10);

			// set T3 value
			mNtpRequest.setT3(System.currentTimeMillis() + serverOffset);

			// Respond to client
			sendNTPAnswer(mNtpRequest);

		}

		private void sendNTPAnswer(NTPRequest request) {
			try {
				ObjectOutputStream oOs = new ObjectOutputStream(clientSocket.getOutputStream());
				oOs.flush(); // -TODO- Flush before write?
				oOs.writeObject(request);
				oOs.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			// Close socket
			try {
				clientSocket.close();
			} catch (Exception e) {
				System.out.println("failed to close socket");
				e.printStackTrace();
			}
		}

	}

}


