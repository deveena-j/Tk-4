import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import static java.lang.Math.round;

public class TimeClient {
	private static String hostUrl = "127.0.0.1";
	private static int PORT = 27780;
	private Double minD;
	private NTPRequest minNTPrequest;
	private Socket clientSocket;
	private NTPRequest minDelayNtpRequest;	// NTP request that had min value for delay

	public TimeClient() {

		try {
			minNTPrequest = new NTPRequest();

			System.out.println("=========================");
			System.out.println("  o \t\t  d");
			System.out.println("=========================");

			//a total of 10 measurements
			for (int i = 0; i < 10; i++) {


				clientSocket = new Socket(InetAddress.getByName(hostUrl), PORT);

				// Send NTP request
				sendNTPRequest();

				// Do measurements
				minNTPrequest.calculateOandD();

				// Check if this is the minimum delay NTP Request so far
				if(minDelayNtpRequest == null || minNTPrequest.getD() < minDelayNtpRequest.getD())
					minDelayNtpRequest = minNTPrequest;

				// wait 300ms before next iteration
				threadSleep(300);

			}

			// Calculate based on min value of d
			doFinalDelayCalculation();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}

	private void sendNTPRequest() {
		// set T1
		minNTPrequest.setT1(System.currentTimeMillis());

		// send request object
		try {

			ObjectOutputStream Os = new ObjectOutputStream(clientSocket.getOutputStream());
			Os.writeObject(minNTPrequest);

			// wait for server's response
			ObjectInputStream Is = new ObjectInputStream(clientSocket.getInputStream());
			minNTPrequest= (NTPRequest) Is.readObject();

			// Close streams
			Os.close();
			Is.close();

		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}


		// Emulate network delay - sleep before recording time stamps
		threadSleep(round(Math.random() * (100 - 10)) + 10);

		// set t4
		minNTPrequest.setT4((long)(System.currentTimeMillis()));

	}

	private void threadSleep(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new TimeClient();
	}

	/**
	 * Selects a NTPRequest based on min value of delay for each request
	 */
	private void doFinalDelayCalculation(){
		System.out.println("------------------------");
		System.out.println("Selected time difference   : " + minDelayNtpRequest.getD());
		System.out.println("Corresponding clock offset : " + minDelayNtpRequest.getO());
		System.out.println("Corresponding accuracy   : "
				+ minDelayNtpRequest.getAccuracyMin()
				+ " to "
				+ minDelayNtpRequest.getAccuracyMax() );
	}
}
